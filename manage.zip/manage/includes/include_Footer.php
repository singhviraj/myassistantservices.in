 <!-- footer content -->
 <footer>
     <div class="pull-right">
         Admin Template Footer</a>
     </div>
     <div class="clearfix"></div>
 </footer>
 <!-- /footer content -->

  <!-- validator -->
  <script src="resources/vendors/validator/validator.js"></script>
  <!-- Bootstrap -->
  <script src="resources/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
  <!-- FastClick -->
  <script src="resources/vendors/fastclick/lib/fastclick.js"></script>
  <!-- NProgress -->
  <script src="resources/vendors/nprogress/nprogress.js"></script>
  <!-- Datatables -->
  <script src="resources/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
  <script src="resources/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
  <script src="resources/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
  <script src="resources/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
  <script src="resources/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
  <script src="resources/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
  <script src="resources/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
  <script src="resources/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
  <script src="resources/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
  <script src="resources/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
  <script src="resources/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
  <script src="resources/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
  <script src="resources/vendors/jszip/dist/jszip.min.js"></script>
  <script src="resources/vendors/pdfmake/build/pdfmake.min.js"></script>
  <script src="resources/vendors/pdfmake/build/vfs_fonts.js"></script>
  <!-- Moment Script  to be loaded before datepicker-->
  <script src="resources/vendors/moment/min/moment.min.js"></script>
  <!-- Custom Theme Scripts -->
  <script src="resources/vendors/Chart.js/dist/Chart.min.js"></script>
  <script src="resources/build/js/custom.js"></script>
  <!-- <script src="resources/vendors/Chart.js/dist/Chart.min.js"></script> -->
  <!-- bootstrap-datetimepicker -->
  <script src="resources/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
  <!-- bootstrap-dateRangepicker -->
  <script src="resources/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>

  <!-- Upload File Start-->
  <script src="resources/build/js/bootstrap-imageupload/bootstrap-imageupload.js"></script>
  
 <script>
var $imageupload = $('.imageupload');
$imageupload.imageupload();
 </script>
 <!-- Upload File End-->