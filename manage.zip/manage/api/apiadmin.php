<?php
	session_start();
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    include "inc/config.php";

    $action = isset($_POST['action']) ? $_POST['action'] : "no_action";
    
//function for user login (BOD by laleshwar)
if ($action==='loginUsers'){
    $returned_data = new stdClass();
    if($_POST['loginid']==null or $_POST['password']== null){
        $returned_data->success = false;
        $returned_data->msg = 'Please Provide User Id And Password'; 
        die( json_encode($returned_data) );
    }
    
    $userId = $_POST['loginid'];
    $pass = md5($_POST['password']);
    $arr=$db->query("SELECT * FROM admin WHERE LoginID = '$userId' AND Password = '$pass' AND IsDeleted = 0 ");
    //var_dump( $arr); die;
    $dataCout= count($arr);
    if($dataCout == 0){
        $returned_data->result = $dataCout;
        $returned_data->success = false;
        $returned_data->data = 0;
        $returned_data->msg = 'Invalid Username or Password';
    }else{
        $data = new stdClass();
        $data->records = $arr ;
        $returned_data->success = true;
        $Username = $arr[0]["FirstName"]." ".$arr[0]["LastName"];
        $UserID = $arr[0]["UserID"];
        $UserType = $arr[0]["UserType"];
        $LoginID = $arr[0]["LoginID"];
        $EmailID = $arr[0]["EmailID"];
        $UniqueID = $arr[0]["UniqueID"];
    
        // if ( $arr[0]["IsVerified"] == 0) {
        //     $enCodeEmail = base64_encode($arr[0]["EmailID"]);
        //     $enCodeloginID = base64_encode($arr[0]["LoginID"]);
        //     $enCodeUniqueID = base64_encode($arr[0]["UniqueID"]);
        //     $VerificationURL = $ApplicationUrl."userVerification.php?EmailID=$enCodeEmail&LoginID=$enCodeloginID&UniqueID=$enCodeUniqueID" ;

        //     $to = $arr[0]["EmailID"]; // WebSite Owner Mail Static
        //     $subject = "Email Verification Mail";
        //     $txt = "Please Click On link Given Below to Verify Your Email"."\n".$VerificationURL;
        //     $headers = "From: webmaster@example.com";
        //     $check = mail($to,$subject,$txt,$headers);
        //     $returned_data->msg = 'You have not verified your account. Please Verify your account to login. We have send an Email Just Now'; 
        //     $returned_data->result = $dataCout;
        //     $returned_data->success = false;
        //     $returned_data->data = 0;
        //     die( json_encode($returned_data) );    
        // }
        if ( $arr[0]["IsActive"] == 0) {
            // Your verification is pending.  Please Verify your account to login.
            $returned_data->msg = 'Your Account is disable !! please contact to admin for activate Account'; 
            $returned_data->result = $dataCout;
            $returned_data->success = false;
            $returned_data->data = 0;
            die( json_encode($returned_data) );    
        }
        //// new BOC By laleshwar
        if($UserType == 5){
                $returned_data->result = $dataCout;
                $_SESSION['username'] = $Username;
                $_SESSION['UserID'] = $UserID;
                $_SESSION['UserType'] = $UserType;
                $_SESSION['LoginID'] = $LoginID;
                $_SESSION['EmailID'] = $EmailID;
                $_SESSION['UniqueID'] = $UniqueID;
                $returned_data->data = $data;
            }
            
    }

    die( json_encode($returned_data) );
} 
    //============================================//

// insert Product details

if ($action==='insertProductData'){
    $return_data = new stdClass();
    if($_POST['productName']==null or $_POST['brandName']== null or $_SESSION['UserID']==null){
        $return_data->data=0;
        $return_data->success = false;
        $return_data->msg = 'Mandatory Data Missing..!'; 
        die( json_encode($return_data) );
    }

    $filename = pathinfo($_FILES['fbimage']['name'], PATHINFO_FILENAME);
    // var_dump($filename); die();

    $UserID = $_SESSION['UserID'];
    if($_POST['check1']!= 0){
        $filename = pathinfo($_FILES['fbimage']['name'], PATHINFO_FILENAME);    
        $filename = str_replace(" ","_",$filename);    
        $test = explode('.', $_FILES['fbimage']['name']);
        $extension = end($test); 
        $name = mt_rand(100,999).$filename.date('dyms').'.'.$extension;
    }else{
         $name = 'Not Selected';
    }

    if($_POST['check2']!= 0){        
        $filename2 = pathinfo($_FILES['twimage']['name'], PATHINFO_FILENAME);
        $filename2 = str_replace(" ","_",$filename2);
        $test2 = explode('.', $_FILES['twimage']['name']);
        $extension = end($test2); 
        $name2 = mt_rand(100,999).$filename2.date('dyms').'.'.$extension;
    }else{       
         $name2 = 'Not Selected';
    }

    if($_POST['check3']!= 0){        
        $filename3 = pathinfo($_FILES['template']['name'], PATHINFO_FILENAME);
        $filename3 = str_replace(" ","_",$filename3);
        $test2 = explode('.', $_FILES['template']['name']);
        $extension = end($test2); 
        $templatefile = mt_rand(100,999).$filename3.date('dyms').'.'.$extension;
    }else{       
         $templatefile = 'Not Selected';
    }

    $data=array(
        'ProductName'=>$_POST['productName'],
        'BrandName'=>$_POST['brandName'],
        'ProductCategoryID'=>$_POST['ddlCategoryType'],
        'SalesPrice'=>$_POST['salesPrice'],
        'BasePrice'=>$_POST['basePrice'],
        'StockQuantity'=>$_POST['stock'],
        'AltTagFirst'=>$_POST['altagImage1'],
        'AltTagSecond'=>$_POST['altagImage2'],
        'Description'=>$_POST['descripion'],
        'Templatefile'=>$templatefile,
        'VideoURL'=>$_POST['videoUrl'],
        'ImageOne'=>$name,
        'ImageSecond'=>$name2
    );   
    $rs=$db->insert('masterproduct', $data,'');
    
    $LastProductID = $db->getLastInsertId();

    if ($name != 'Not Selected') {
        if(!file_exists('../assets/'.$LastProductID)){
             mkdir('../assets/'.$LastProductID);
            if(!file_exists('../assets/'.$LastProductID.'/firstimage')){
                 mkdir('../assets/'.$LastProductID.'/firstimage');
            }           
            $location = '../assets/'.$LastProductID.'/firstimage'.'/'.$name;
            move_uploaded_file($_FILES['fbimage']['tmp_name'], $location);
        }else{
             if(!file_exists('../assets/'.$LastProductID.'/firstimage')){
                 mkdir('../assets/'.$LastProductID.'/firstimage');
            }  

            $location = '../assets/'.$LastProductID.'/firstimage'.'/'.$name;
            move_uploaded_file($_FILES['fbimage']['tmp_name'], $location);
        }         
    }
    // here start code for secong meta image insertion-----------============-----------
     if($name2 != 'Not Selected'){
        if(!file_exists('../assets/'.$LastProductID)){
             mkdir('../assets/'.$LastProductID);
            if(!file_exists('../assets/'.$LastProductID.'/secondImage')){
                 mkdir('../assets/'.$LastProductID.'/secondImage');
            }           
            $location2 = '../assets/'.$LastProductID.'/secondImage'.'/'.$name2;
            move_uploaded_file($_FILES['twimage']['tmp_name'], $location2);
        }else{
             if(!file_exists('../assets/'.$LastProductID.'/secondImage')){
                 mkdir('../assets/'.$LastProductID.'/secondImage');
            }  

            $location2 = '../assets/'.$LastProductID.'/secondImage'.'/'.$name2;
            move_uploaded_file($_FILES['twimage']['tmp_name'], $location2);
        }
     }   

      // here start code for secong meta image insertion-----------============-----------
     if($templatefile != 'Not Selected'){
        if(!file_exists('../assets/templates/'.$LastProductID)){
             mkdir('../assets/templates/'.$LastProductID);
            if(!file_exists('../assets/templates/'.$LastProductID)){
                 mkdir('../assets/templates/'.$LastProductID);
            }           
            $locationforfile = '../assets/templates/'.$LastProductID.'/'.$templatefile;
            move_uploaded_file($_FILES['template']['tmp_name'], $locationforfile);
        }else{
             if(!file_exists('../assets/templates/'.$LastProductID)){
                 mkdir('../assets/templates/'.$LastProductID);
            }  

            $locationforfile = '../assets/templates/'.$LastProductID.'/'.$templatefile;
            move_uploaded_file($_FILES['template']['tmp_name'], $locationforfile);
        }
     }   

    if ($rs == true) {
        $return_data->ProductID=$LastProductID;
        $return_data->fileName=$name;
        $return_data->fileName2=$name2;
        $return_data->filename3=$templatefile;
        $return_data->data=1;
        $return_data->success=true;
        $return_data->msg='Product information saved successfully.';
    }else{
        $return_data->data=0;
        $return_data->success=false;
        $return_data->msg='Failed!, Product Data not saved';  
    }
    die( json_encode($return_data) );
}

//----- Master Builder List Start ----------
if ($action==='listMasterProductData'){
    $returned_data = new stdClass();
    if($_SESSION['UserID']==null){
        $returned_data->success = false;
        $returned_data->msg = 'Manadatory data missing.'; 
        $returned_data->data = 0; 
        die( json_encode($returned_data) );
    }
    $sql="SELECT mp.ProductID, mp.ProductName, mp.BrandName, mp.SalesPrice, mp.StockQuantity, pc.ProductCategoryID, pc.CategoryName FROM masterproduct mp LEFT JOIN productcategory pc ON pc.ProductCategoryID =mp.ProductCategoryID ORDER BY mp.ProductID DESC";
    $rs=$db->query($sql);
    if(count($rs)>0){
        $returned_data->data = $rs;
        $returned_data->success = true;
        $returned_data->msg = 'Success';
    }else{
        $returned_data->data = 0;
        $returned_data->success = true;
        $returned_data->msg = 'Master builder not record found';
    }    
    die( json_encode($returned_data) );
}

//--------- Get Master Product Data ----------
if ($action==='getProductInfoById'){
    $productID=$_POST['ProductID'];
    $return_data = new stdClass();
    $rs=$db->fetchSingleRow('masterproduct', 'ProductID', $productID);
    if ($rs!=NULL) {
        $return_data->data = $rs;
        $return_data->success = true;
    } else {
        $return_data->data = 0;
        $return_data->success = false;
    }
    die( json_encode($return_data) );
}

// update master product Data
if ($action==='updateProductData'){
    $return_data = new stdClass();
    
    if($_POST['productId']==null or $_POST['productName']== null or $_POST['brandName']==null){
        $return_data->data=0;
        $return_data->success = false;
        $return_data->msg = 'Mandatory Data Missing..!'; 
        die( json_encode($return_data) );
    }
   // $UserID = $_SESSION['UserID'];
    $productId=$_POST['productId'];

    $sqlQuery = "SELECT ImageOne,ImageSecond FROM masterproduct WHERE ProductID = $productId";
    $OldImage = $db->query($sqlQuery);
    $OldImage1 = $OldImage[0]['ImageOne'];
    $OldImage2 = $OldImage[0]['ImageSecond'];
    
    if ($_POST['check1'] != 0 ) {
        $filename = pathinfo($_FILES['fbimage']['name'], PATHINFO_FILENAME);    
        $filename = str_replace(" ","_",$filename);    
        $test = explode('.', $_FILES['fbimage']['name']);
        $extension = end($test); 
        $name = mt_rand(100,999).$filename.date('dyms').'.'.$extension;
    }else{
        $name = 'Not Selected';
    }
    if ($_POST['check2'] != 0 ) {
        $filename2 = pathinfo($_FILES['twimage']['name'], PATHINFO_FILENAME);
        $filename2 = str_replace(" ","_",$filename2);
        $test2 = explode('.', $_FILES['twimage']['name']);
        $extension = end($test2); 
        $name2 = mt_rand(100,999).$filename2.date('dyms').'.'.$extension;
    }else{
        $name2 = 'Not Selected';
    }
    
    $data=array(
        'ProductName'=>$_POST['productName'],
        'BrandName'=>$_POST['brandName'],
        'ProductCategoryID'=>$_POST['ddlCategoryType'],
        'SalesPrice'=>$_POST['salesPrice'],
        'BasePrice'=>$_POST['basePrice'],
        'StockQuantity'=>$_POST['stock'],
        'AltTagFirst'=>$_POST['altagImage1'],
        'AltTagSecond'=>$_POST['altagImage2'],
        'Description'=>$_POST['descripion'],
        'Availability'=>$_POST['availability'],
        'ImageOne'=>$name,
        'ImageSecond'=>$name2
        //'ModifyBy'=>$UserID
    );    
    $rs=$db->update('masterproduct', $data,'ProductID',$productId); 

    if ($name != 'Not Selected') {
        if(!file_exists('../assets/'.$productId.'/firstimage')){
            mkdir('../assets/'.$productId.'/firstimage');
            $location = '../assets/'.$productId.'/firstimage'.'/'.$name;
            move_uploaded_file($_FILES['fbimage']['tmp_name'], $location);
        }else{
            unlink('../assets/'.$productId.'/firstimage'.'/'.$OldImage1);
            $location = '../assets/'.$productId.'/firstimage'.'/'.$name;
            move_uploaded_file($_FILES['fbimage']['tmp_name'], $location);
        }
    }
    // here start code for secong  image insertion-----------============----------- 

    if($name2 !='Not Selected'){
        if(!file_exists('../assets/'.$productId.'/secondImage')){
            mkdir('../assets/'.$productId.'/secondImage');
            $location2 = '../assets/'.$productId.'/secondImage'.'/'.$name2;
            move_uploaded_file($_FILES['twimage']['tmp_name'], $location2);
        }else{
            unlink('../assets/'.$productId.'/secondImage'.'/'.$OldImage2);
            $location2 = '../assets/'.$productId.'/secondImage'.'/'.$name2;
            move_uploaded_file($_FILES['twimage']['tmp_name'], $location2);
        } 
    }
    if ($rs == true) {
        $return_data->ProductID=$productId;
        $return_data->fileName=$name;
        $return_data->fileName2=$name2;
        $return_data->data=1;
        $return_data->success=true;
        $return_data->msg='Product information updated successfully.';
    }else{
        $return_data->data=0;
        $return_data->success=false;
        $return_data->msg='Failed Please Try Again.';  
    }
    die( json_encode($return_data) );
}

// get Master List of All tables.
if ($action==='ListCategoryData'){
    $returned_data = new stdClass();
    if($_SESSION['UserID']==null or $_SESSION['UserType']!=5){
        $returned_data->success = false;
        $returned_data->msg = 'Mandatory data missing..!'; 
        $returned_data->data = 0;
        die( json_encode($returned_data) );
    }
    $sql="SELECT ProductCategoryID, CategoryName FROM productcategory";
    $MasterCategory=$db->query($sql);
    if ($MasterCategory == true) {
        $returned_data->data = 1;
        $returned_data->MasterCategory = $MasterCategory;
        $returned_data->success = true;
        $returned_data->msg = 'All master data found.'; 
    } else {
        $returned_data->success = false;
        $returned_data->msg = 'Data Not Found..'; 
        $returned_data->data = 0;
    }
    die( json_encode($returned_data) );
}

// insert highlights data (BOC BY LALESHWAR 03-08-2022)
if($action==='insertHighLightsData'){
    $returned_data=new stdClass();
    if($_SESSION['UserID']==null or $_SESSION['UserType']!=5 or $_POST['projectId']==null or $_POST['highlight'] ==null){
        $returned_data->success = false;
        $returned_data->msg = 'Manadatory data missing.'; 
        $returned_data->data = 0; 
        die( json_encode($returned_data) );
    }
    $UserID= $_SESSION['UserID'];
    $data=array(
            'HighlightText'=>$_POST['highlight'],
            'ProjectID'=>$_POST['projectId'],
            'CreatedBy'=>$UserID);
    $result=$db->insert('projecthighlight',$data,'');
    if($result==true){
        $returned_data->data=1;
        $returned_data->msg='Highlight saved successfully..!';
        $returned_data->success=true;  
    }else{
        $returned_data->data=0;
        $returned_data->msg='Failed!, highlight not saved';
        $returned_data->success=false; 
    }
     die( json_encode($returned_data) );
}

// Fetch Highloights data (BOC by laleshwar 03-08-2022)
if ($action==='listHighLightData'){
    $returned_data = new stdClass();
    if($_SESSION['UserID']==null or $_SESSION['UserType']!=5 or $_POST['ProjectId']==null){
        $returned_data->success = false;
        $returned_data->msg = 'Manadatory data missing.'; 
        $returned_data->data = 0; 
        die( json_encode($returned_data) );
    }
    
    $ProjectId=$_POST['ProjectId'];

    $sql="SELECT HighlightText,ProjectHighlightID  FROM projecthighlight WHERE ProjectID=$ProjectId LIMIT 20";
    //var_dump($sql); die;
    $rs=$db->query($sql);
    if(count($rs)>0){
        $returned_data->data =  $rs;
        $returned_data->success =true;
        $returned_data->msg = 'Highlight data';
    }else{
        $returned_data->data = 0;
        $returned_data->data = false;
        $returned_data->msg = 'Highlight data not faund';
    }    
    die( json_encode($returned_data) );
}

//functin for get Highlights data (BOC by laleshwar)
if ($action==='getHighLightinfoById'){
    $returned_data = new stdClass();
    if($_SESSION['UserID']==null or $_SESSION['UserType']!=5 or $_POST['ProjectHighlightID']==null){
         $returned_data->success = false;
         $returned_data->msg = 'Manadatory data missing.'; 
         $returned_data->data = 0; 
         die( json_encode($returned_data) );
     }
     $hightId=$_POST['ProjectHighlightID'];
     // $sql="SELECT * FROM `ProjectHighlight` WHERE ProjectHighlightID='$hightId'";
     // $rs=$db->query($sql);
     $rs=$db->fetchSingleRow('projecthighlight', 'ProjectHighlightID', $hightId);
     if($rs!=null){
         $returned_data->data =  $rs;
         $returned_data->success = true;
         $returned_data->msg = 'Highlight data';
     }else{
         $returned_data->data = 0;
         $returned_data->success = false;
         $returned_data->msg = 'Highlight data not found';
     }    
     die( json_encode($returned_data) );
}

// function for update Highlights
if ($action==='updateHighlightInfoById'){
    $returned_data = new stdClass();
    if($_SESSION['UserID']==null or $_SESSION['UserType']!=5 or $_POST['ProductHighlightID']==null){
        $returned_data->success = false;
        $returned_data->msg = 'Manadatory data missing.'; 
        $returned_data->data = 0; 
        die( json_encode($returned_data) );
    }
    $userId=$_SESSION['UserID'];
    $hightId=$_POST['ProductHighlightID'];
    $data=array(
        'HighlightText'=>$_POST['HighlightText'],
        'ModifyBy'=>1
        );
    $rs=$db->update('projecthighlight', $data, 'ProjectHighlightID',$hightId);
    if ($rs == true) {
        $returned_data->success = true;
        $returned_data->data=1;
        $returned_data->msg='Highlight updated Successfully!';
    }else{
        $returned_data->success = false;
        $returned_data->data=0;
        $returned_data->msg='Failed!, highlight not updated';
    }       
    die( json_encode($returned_data) );
} 

// function for delete  product highlights
if ($action==='deleteHighlightInfoById'){
    $returned_data = new stdClass();
    if($_SESSION['UserID']==null or $_SESSION['UserType']!=5){
        $returned_data->success = false;
        $returned_data->msg = 'Manadatory data missing.'; 
        $returned_data->data = 0; 
        die( json_encode($returned_data) );
    }
    $hightId=$_POST['ProductHighlightID'];

    $sql="DELETE FROM projecthighlight WHERE ProjectHighlightID=$hightId";

    $rs=$db->query($sql);
    if (count($rs)>0) {
        $returned_data->success=false;
        $returned_data->data=1;
        $returned_data->msg='Failed Please Try Again.';
    }else{
        $returned_data->success=true;
        $returned_data->data=0;
        $returned_data->msg=' Highlight deleted successfully!';
    }       
    die( json_encode($returned_data) );
} 

// function for delete Product
if ($action==='deleteProject'){
    $returned_data = new stdClass();
    if($_SESSION['UserID']==null or $_SESSION['UserType']!=5){
        $returned_data->success = false;
        $returned_data->msg = 'Manadatory data missing.'; 
        $returned_data->data = 0; 
        die( json_encode($returned_data) );
    }
    $ProductID=$_POST['ProductID'];

    $sql="DELETE FROM masterproduct WHERE ProductID =$ProductID";

    $rs=$db->query($sql);
    if (count($rs)>0) {
        $returned_data->success=false;
        $returned_data->data=1;
        $returned_data->msg='Failed Please Try Again.';
    }else{
        $returned_data->success=true;
        $returned_data->data=0;
        $returned_data->msg=' Product deleted successfully!';
    }       
    die( json_encode($returned_data) );
} 


if ($action === 'insertMasterBlogdata') {
    $return_data = new stdClass();
    if (!isset($_POST['BlogName']) || !isset($_SESSION['UserID']) || $_SESSION['UserType'] != 5) {
        $return_data->data = 0;
        $return_data->success = false;
        $return_data->msg = 'Mandatory Data Missing..!';
        die(json_encode($return_data));
    }
    $UserID = $_SESSION['UserID'];
    if (isset($_POST['check']) && $_POST['check'] != 0) {
        $filename = isset($_FILES['file']['name']) ? pathinfo($_FILES['file']['name'], PATHINFO_FILENAME) : '';
        $filename = str_replace(" ", "_", $filename);
        $test = isset($_FILES['file']['name']) ? explode('.', $_FILES['file']['name']) : [];
        $extension = end($test);
        $name = mt_rand(100, 999) . $filename . date('dyms') . '.' . $extension;
    } else {
        $name = 'Not Selected';
    }

    $Blogname = isset($_POST['BlogName']) ? $_POST['BlogName'] : '';
    $content = isset($_POST['Contant']) ? $_POST['Contant'] : '';
    $data = array(
        'Name' => $Blogname,
        'Headshot' => $name,
        'Contant' => $content        
    );

    $countSql = "INSERT INTO `blog`(`Name`, `Headshot`, `Contant`) VALUES ('$Blogname','$name','$content')";
    $res = $db->query($countSql);
    $LastBlogId = $db->getLastInsertId();
    
    if ($name != 'Not Selected') {
        if(!file_exists('../assets/blogs/'.$LastBlogId)){
            mkdir('../assets/blogs/'.$LastBlogId);
            $location = '../assets/blogs/'.$LastBlogId.'/'.$name;
            move_uploaded_file($_FILES['file']['tmp_name'], $location);
        }else{
            $location = '../assets/blogs/'.$LastBlogId.'/'.$name;
            move_uploaded_file($_FILES['file']['tmp_name'], $location);
        }
    }
    if (count($res) == 0) {
        $return_data->BuilderID=$LastBlogId;
        $return_data->fileName=$name;
        $return_data->data=1;
        $return_data->success=true;
        $return_data->msg='Blog saved Successfully.';
    }else{
        $return_data->data=0;
        $return_data->success=false;
        $return_data->msg='Failed Please Try Again.';  
    }
    die( json_encode($return_data) );
}

// Fetch blog data (BOC by laleshwar 013-07-2023)
if ($action==='listMasterBlog'){
    $returned_data = new stdClass();
    if($_SESSION['UserID']==null or $_SESSION['UserType']!=5){
        $returned_data->success = false;
        $returned_data->msg = 'Manadatory data missing.'; 
        $returned_data->data = 0; 
        die( json_encode($returned_data) );
    }
    
    $sql="SELECT BlogId, Name, Headshot, Create_at FROM `blog` ORDER BY BlogId DESC";
    $rs=$db->query($sql);

    if(count($rs)>0){
        $returned_data->data =  $rs;
        $returned_data->success =true;
        $returned_data->msg = 'Highlight data';
    }else{
        $returned_data->data = 0;
        $returned_data->data = false;
        $returned_data->msg = 'Highlight data not faund';
    }    
    die( json_encode($returned_data) );
}


// function for delete Blog
if ($action==='deleteBlog'){
    $returned_data = new stdClass();
    if($_SESSION['UserID']==null or $_SESSION['UserType']!=5){
        $returned_data->success = false;
        $returned_data->msg = 'Manadatory data missing.'; 
        $returned_data->data = 0; 
        die( json_encode($returned_data) );
    }
    $blogId=$_POST['blogId'];

    $sql="DELETE FROM blog WHERE BlogId  =$blogId";

    $rs=$db->query($sql);
    if (count($rs)>0) {
        $returned_data->success=false;
        $returned_data->data=1;
        $returned_data->msg='Failed Please Try Again.';
    }else{
        $returned_data->success=true;
        $returned_data->data=0;
        $returned_data->msg=' Product deleted successfully!';
    }       
    die( json_encode($returned_data) );
} 

if ($action==='no_action'){
    $returned_data = new stdClass();
    $returned_data->error = 'Something is wrong :-(';
    die( json_encode($returned_data) );
}
   

?>
Something is wrong :-(