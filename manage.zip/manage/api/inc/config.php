<?php

$host = "localhost";
$port = 3306;
$db_username = "root";
$db_password = "";
$db_name = "job-seeker";
require_once("Database.php");

$db=new Database($host, $port, $db_username, $db_password, $db_name);

function handleException($exception)
{
    echo  $exception->getMessage();
}

set_exception_handler('handleException');
