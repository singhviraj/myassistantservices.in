<?php
$new_url = 'login.php';
header('Location: '.$new_url);
?>
